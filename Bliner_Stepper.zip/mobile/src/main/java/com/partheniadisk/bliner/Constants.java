package com.partheniadisk.bliner;

/**
 * Created by gpart on 21/10/2017.
 */
public class Constants {
    public static final String PATH_NOTIFICATION = "/ongoingnotification";
    public static final String PATH_DISMISS = "/dismissnotification";
    public static final String KEY_TITLE = "title";
    public static final String KEY_IMAGE = "image";
}
